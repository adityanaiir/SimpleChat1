// This file contains material supporting section 3.7 of the textbook:
// "Object Oriented Software Engineering" and is issued under the open-source
// license found at www.lloseng.com 

import java.io.*;
import ocsf.server.*;

/**
 * This class overrides some of the methods in the abstract 
 * superclass in order to give more functionality to the server.
 *
 * @author Dr Timothy C. Lethbridge
 * @author Dr Robert Lagani&egrave;re
 * @author Fran&ccedil;ois B&eacute;langer
 * @author Paul Holden
 * @version July 2000
 */
public class EchoServer extends AbstractServer 
{
  //Class variables *************************************************
  
  /**
   * The default port to listen on.
   */
  final public static int DEFAULT_PORT = 5555;
  
  //Constructors ****************************************************
  
  /**
   * Constructs an instance of the echo server.
   *
   * @param port The port number to connect on.
   */
  public EchoServer(int port) 
  {
    super(port);
  }

  
  //Instance methods ************************************************
  
  /**
   * This method handles any messages received from the client.
   *
   * @param msg The message received from the client.
   * @param client The connection from which the message originated.
   */
  public void handleMessageFromClient(Object msg, ConnectionToClient client)
  {
    String keyword = msg.toString();
    if(keyword.startsWith("#"))
    {
      String[] mssgg = keyword.split(" ");
      if(mssgg[0].equals("#login") && client.getInfo("loginid") == null)
      {
        try{
          System.out.println("id not available.");
          client.close();
        }
        catch(IOException e){}
      }
      else if(mssgg[0].equals("#login") && client.getInfo("loginid") != null)
      {
        client.setInfo("loginid",mssgg[1]); 
      }
    }
    System.out.println("Message received: " + msg + " from " + client);
    this.sendToAllClients(client.getInfo("loginid") +  "to" + msg);
  }

  public void handleMessageFromServerConsole(String message)
  {
    if (message.startsWith("#")) 
    {
      String[] elems = message.split(" ");
      String comm = elems[0];
      switch (comm)
      {
        case "#quit":
          try
          {
            close();
          }
          catch(IOException e)
          {
            System.out.println("Could not quit the server!");
          }
          break;
        case "#stop":
          stopListening();
          break;
        case "#close":
          try
          {
          close();
          }
          catch(IOException e)
          {
            System.out.println("Not able to close!");
          }
          break;
        case "#setport":
          if (!isListening())
          {
            this.setPort(Integer.parseInt(elems[1]));
          } 
          else 
          {
            System.out.println("Cannot perform the command since the server is not closed!");
          }
          break;
        case "#start":
          if (isListening()) 
          {
            System.out.println("Cannot perform the command since you are already connected!");
          } 
          else 
          {
            try 
            {
                this.listen();
            } 
            catch (IOException e) 
            {
                System.out.println("Connection was not made!");
            }
          }
          break;
        case "#getport":
          System.out.println("The Port is " + this.getPort());
          break;
        default:
          System.out.println("Invalid input");
          break;
      }
    }
  }
  /**
   * This method overrides the one in the superclass.  Called
   * when the server starts listening for connections.
   */
  protected void serverStarted()
  {
    System.out.println("Server listening for connections on port " + getPort());
  }
  
  /**
   * This method overrides the one in the superclass.  Called
   * when the server stops listening for connections.
   */
  protected void serverStopped()
  {
    System.out.println("Server has stopped listening for connections.");
  }
  //prints a message when the client is connected
  protected void clientConnected(ConnectionToClient client) 
  {
    System.out.println(client + "is connected to the server");
  }
  //prints a message when the client is disconnected 
  synchronized protected void clientDisconnected(ConnectionToClient client) 
  {
    System.out.println(client + "has disconnected with the server");
  }


  //Class methods ***************************************************
  
  /**
   * This method is responsible for the creation of 
   * the server instance (there is no UI in this phase).
   *
   * @param args[0] The port number to listen on.  Defaults to 5555 
   *          if no argument is entered.
   */
  public static void main(String[] args) 
  {
    int port = 0; //Port to listen on

    try
    {
      port = Integer.parseInt(args[0]); //Get port from command line
    }
    catch(Throwable t)
    {
      port = DEFAULT_PORT; //Set port to 5555
    }
  
    EchoServer sv = new EchoServer(port);
    
    try 
    {
      sv.listen(); //Start listening for connections
    } 
    catch (Exception ex) 
    {
      System.out.println("ERROR - Could not listen for clients!");
    }
  }
//End of EchoServer class
}


